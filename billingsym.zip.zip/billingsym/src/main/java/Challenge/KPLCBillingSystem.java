/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Challenge;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class KPLCBillingSystem {
    private List<Customer> customers;
    private Map<String, Customer> customerMap;

    public KPLCBillingSystem() {
        this.customers = new ArrayList<>();
        this.customerMap = new HashMap<>();
    }

    public void addCustomer(String name, String meterNumber) {
        Customer customer = new Customer(name, meterNumber);
        customers.add(customer);
        customerMap.put(meterNumber, customer);
    }

    public void generateBill(String meterNumber, double amount, String token, String paymentMethod) {
        Customer customer = customerMap.get(meterNumber);
        if (customer != null) {
            Bill bill = new Bill(LocalDate.now(), amount, token, paymentMethod);
            customer.addBill(bill);
        } else {
            System.out.println("Customer not found!");
        }
    }

    public void markBillAsPaid(String meterNumber, LocalDate date) {
        Customer customer = customerMap.get(meterNumber);
        if (customer != null) {
            for (Bill bill : customer.getBillHistory()) {
                if (bill.getDate().equals(date)) {
                    bill.markAsPaid();
                    break;
                }
            }
        } else {
            System.out.println("Customer not found!");
        }
    }

    public void generateReport(String meterNumber) {
        Customer customer = customerMap.get(meterNumber);
        if (customer != null) {
            System.out.println("Customer: " + customer.getName());
            System.out.println("Meter Number: " + customer.getMeterNumber());
            System.out.println("Bill History:");
            for (Bill bill : customer.getBillHistory()) {
                System.out.println(
                    "Date: " + bill.getDate()
                    + ", Amount: " + bill.getAmount()
                    + ", Token: " + bill.getToken()
                    + ", Payment Method: " + bill.getPaymentMethod()
                    + ", Status: " + (bill.isPaid() ? "Paid" : "Unpaid")
                );
            }
        } else {
            System.out.println("Customer not found!");
        }
    }

    public void getCustomerInfo(String meterNumber) {
        Customer customer = customerMap.get(meterNumber);
        if (customer != null) {
            System.out.println("Customer Name: " + customer.getName());
            System.out.println("Meter Number: " + customer.getMeterNumber());
        } else {
            System.out.println("Customer not found!");
        }
    }
}
