/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package Challenge;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        KPLCBillingSystem billingSystem = new KPLCBillingSystem();

        billingSystem.addCustomer("Ragira Trizer", "MTR12345");
        billingSystem.addCustomer("Bevan Nyandieka", "MTR67890");

        billingSystem.generateBill("MTR12345", 5000, "TOKEN123", "M-Pesa");
        billingSystem.generateBill("MTR67890", 3000, "TOKEN456", "Bank Transfer");

        billingSystem.markBillAsPaid("MTR12345", LocalDate.now());
        billingSystem.markBillAsPaid("MTR67890", LocalDate.now());

        billingSystem.generateReport("MTR12345");
        billingSystem.generateReport("MTR67890");
    }
}



