/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Challenge;

import java.time.LocalDate;

class Bill {
    private LocalDate date;
    private double amount;
    private String token;
    private String paymentMethod;
    private boolean isPaid;

    public Bill(LocalDate date, double amount, String token, String paymentMethod) {
        this.date = date;
        this.amount = amount;
        this.token = token;
        this.paymentMethod = paymentMethod; // FIX: use the parameter
        this.isPaid = false;
    }

    public LocalDate getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public String getToken() {
        return token;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public void markAsPaid() {
        isPaid = true;
    }
}
