/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Challenge;

import java.util.ArrayList;
import java.util.List;

class Customer {
    private String name;
    private String meterNumber;
    private List<Bill> billHistory;

    public Customer(String name, String meterNumber) {
        this.name = name;
        this.meterNumber = meterNumber;
        this.billHistory = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public List<Bill> getBillHistory() {
        return billHistory;
    }

    public void addBill(Bill bill) {
        billHistory.add(bill);
    }
}
    
  

